package mainApp;

import java.util.Scanner;
import java.util.Random;

public class Part2 {
    private int messageAccumulator = 0;

    /**
     * Rubric Check: Returns the total number of messages sent.
     */
    public int returnTotalMessagess() {
        return this.messageAccumulator;
    }

    public void displayFeatureMenu(Scanner input, Login userSession) {
        boolean featureRunning = true;

        while (featureRunning) {
            System.out.println("\n--- QuickChat Features ---");
            System.out.println("1. Send Messages");
            System.out.println("2. View Recently Sent");
            System.out.println("3. Quit");
            System.out.print("Enter choice (1-3): ");

            String choice = input.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("How many messages do you wish to enter? ");
                    int count = 0;
                    try {
                        count = Integer.parseInt(input.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Please enter a valid integer number.");
                        continue;
                    }

                    Message msgProcessor = new Message();

                    for (int i = 0; i < count; i++) {
                        System.out.println("\n--- Entering Message " + (i + 1) + " of " + count + " ---");
                        System.out.print("Enter Recipient Cell Number (include +27): ");
                        String cell = input.nextLine();

                        String cellCheckResult = msgProcessor.checkRecipientCell(cell);
                        System.out.println(cellCheckResult);

                        if (!cellCheckResult.equals("Cell phone number successfully captured.")) {
                            continue;
                        }

                        System.out.print("Enter Message Text (Max 250 characters): ");
                        String text = input.nextLine();

                        // Rubric Check: Exact character excess evaluation layout message
                        if (text.length() > 250) {
                            int excess = text.length() - 250;
                            System.out.println("Message exceeds 250 characters by " + excess + "; please reduce the size.");
                            continue;
                        }

                        System.out.println("Message ready to send.");
                        
                        // Rubric Check: Sub-menu interaction workflow options sheet
                        System.out.println("\nChoose an option for this message:");
                        System.out.println("1. Send Message");
                        System.out.println("2. Disregard Message");
                        System.out.println("3. Store Message to send later");
                        System.out.print("Enter action choice (1-3): ");
                        String actionChoice = input.nextLine();

                        String actionResult = msgProcessor.SentMessage(actionChoice);
                        System.out.println(actionResult);

                        if (actionChoice.equals("1") || actionChoice.equals("3")) {
                            // Generate Message ID
                            Random rand = new Random();
                            StringBuilder sb = new StringBuilder();
                            for (int k = 0; k < 10; k++) {
                                sb.append(rand.nextInt(10));
                            }
                            String generatedId = sb.toString();

                            if (msgProcessor.checkMessageID(generatedId)) {
                                System.out.println("Message ID generated: " + generatedId);
                            }

                            String hash = msgProcessor.createMessageHash(cell, i, text);
                            
                            if (actionChoice.equals("3")) {
                                msgProcessor.storeMessage(hash, cell, text);
                            }

                            System.out.println(msgProcessor.printMessages(hash, cell, text));
                            messageAccumulator++;
                        }
                    }

                    System.out.println("=========================================");
                    System.out.println("Total number of messages accumulated sent: " + returnTotalMessagess());
                    System.out.println("=========================================");
                    break;

                case "2":
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    System.out.println("Returning to Main Application Menu...");
                    featureRunning = false;
                    break;

                default:
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }
    }
}