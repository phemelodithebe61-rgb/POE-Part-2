package mainApp;

/**
 * Login class handles user account creation and authentication.
 * This implementation follows assignment specifications exactly.
 */
public class Login {
    
    // Private member variables for user data
    private String userFirst;
    private String userLast;
    private String userUsername;
    private String userPassword;
    private String userCell;

    /**
     * Login constructor accepts all registration information.
     * * @param userFirst User's first name
     * @param userLast User's last name
     * @param userUsername Desired username
     * @param userPassword Desired password
     * @param userCell Cell phone number with +27 code
     */
    public Login(String userFirst, String userLast, String userUsername, String userPassword, String userCell) {
        this.userFirst = userFirst;
        this.userLast = userLast;
        this.userUsername = userUsername;
        this.userPassword = userPassword;
        this.userCell = userCell;
    }

    /**
     * Validates username format.
     * Condition 1: Must contain underscore character (_)
     * Condition 2: Must be 5 characters or less in length
     * * @return boolean indicating username validity
     */
    public boolean checkUserName() {
        return userUsername.contains("_") && userUsername.length() <= 5;
    }

    /**
     * Validates password complexity.
     * Condition 1: Length must be at least 8 characters
     * Condition 2: Must contain at least one uppercase letter
     * Condition 3: Must contain at least one numeric digit
     * Condition 4: Must contain at least one special character
     * * @return boolean indicating password validity
     */
    public boolean checkPasswordComplexity() {
        boolean upperFlag = false;
        boolean digitFlag = false;
        boolean specialFlag = false;

        if (userPassword.length() < 8) {
            return false;
        }

        for (int index = 0; index < userPassword.length(); index++) {
            char ch = userPassword.charAt(index);
            
            if (Character.isUpperCase(ch)) upperFlag = true;
            if (Character.isDigit(ch)) digitFlag = true;
            if (!Character.isLetterOrDigit(ch)) specialFlag = true;
        }

        return upperFlag && digitFlag && specialFlag;
    }

    /**
     * Validates South African cell phone number format.
     * Format must be: +27 followed by exactly 9 digits.
     * * @return boolean indicating phone number validity
     */
    public boolean checkCellPhoneNumber() {
        return userCell.matches("^\\+27\\d{9}$");
    }

    /**
     * Registers user by validating all input fields.
     * Returns appropriate error message for first failed validation.
     * Returns success message only when all validations pass.
     * * @return Registration result message
     */
    public String registerUser() {
        if (!this.checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        
        if (!this.checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        
        if (!this.checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    /**
     * Authenticates user login attempt.
     * * @param loginUsername Username entered during login
     * @param loginPassword Password entered during login
     * @return true if credentials match stored values
     */
    public boolean loginUser(String loginUsername, String loginPassword) {
        return userUsername.equals(loginUsername) && userPassword.equals(loginPassword);
    }

    /**
     * Returns login status message.
     * * @param loginUsername Username entered during login
     * @param loginPassword Password entered during login
     * @return Welcome message or error message
     */
    public String returnLoginStatus(String loginUsername, String loginPassword) {
        if (this.loginUser(loginUsername, loginPassword)) {
            return "Welcome " + userFirst + ", " + userLast + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}