package mainApp;

import java.util.Scanner;

/**
 * Main application class for registration and login system.
 */
public class Main {
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("===== REGISTRATION =====");

        System.out.print("Enter first name: ");
        String first = scan.nextLine();

        System.out.print("Enter last name: ");
        String last = scan.nextLine();

        System.out.print("Enter username: ");
        String username = scan.nextLine();

        System.out.print("Enter password: ");
        String password = scan.nextLine();

        System.out.print("Enter South African cell phone number (include +27): ");
        String cell = scan.nextLine();

        Login account = new Login(first, last, username, password, cell);

        String result = account.registerUser();
        System.out.println(result);

        if (account.checkUserName() && account.checkPasswordComplexity() && account.checkCellPhoneNumber()) {
            System.out.println();
            System.out.println("===== LOGIN =====");

            System.out.print("Enter username: ");
            String loginUser = scan.nextLine();

            System.out.print("Enter password: ");
            String loginPass = scan.nextLine();

            System.out.println(account.returnLoginStatus(loginUser, loginPass));
            
            // --- PART 2 INTEGRATION BRIDGE ---
            if (account.loginUser(loginUser, loginPass)) {
                System.out.println("Welcome to QuickChat.");
                
                // Triggers Part 2 menu loop automatically upon successful validation
                Part2 featureMenu = new Part2();
                featureMenu.displayFeatureMenu(scan, account);
            }
        }

        scan.close();
    }
}